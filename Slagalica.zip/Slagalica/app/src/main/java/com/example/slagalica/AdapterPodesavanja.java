package com.example.slagalica;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.PointerIcon;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class AdapterPodesavanja extends RecyclerView.Adapter<AdapterPodesavanja.Kartica> {
    private int           BROJ_UKLJUCENIH_SLIKA;
    private List<Integer> SlikeId,
                          IzabranaSlika;
    private List<String>  NaziviSlika,
                          OpisiSlika;
    private List<Boolean> UkljuceneSlike;
    private Context       context;

    public AdapterPodesavanja(Context context, List<Integer> slikeId, List<String> naziviSlika,
                              List<String> opisiSlika, List<Boolean> ukljuceneSlike,
                              List<Integer> izabranaSlika, int brojUkljucenihSlika) {
        this.context               = context;
        this.SlikeId               = slikeId;
        this.NaziviSlika           = naziviSlika;
        this.OpisiSlika            = opisiSlika;
        this.UkljuceneSlike        = ukljuceneSlike;
        this.IzabranaSlika         = izabranaSlika;
        this.BROJ_UKLJUCENIH_SLIKA = brojUkljucenihSlika;
        //Toast.makeText(context, String.format("BR_UKLJ_P: %d", BROJ_UKLJUCENIH_SLIKA), Toast.LENGTH_SHORT).show();
    }

    @NonNull
    @Override
    public AdapterPodesavanja.Kartica onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View           view     = inflater.inflate(R.layout.kartica_slika, parent, false);
        return new Kartica(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final AdapterPodesavanja.Kartica holder, final int position) {
        holder.nazivTextView.setText(NaziviSlika.get(position));
        holder.opisTextView.setText(OpisiSlika.get(position));
        holder.checkBox.setChecked(UkljuceneSlike.get(position));
        holder.slikaImageView.setImageResource(SlikeId.get(position));

        holder.checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(holder.checkBox.isChecked()) {
                    UkljuceneSlike.set(position, true);
                    BROJ_UKLJUCENIH_SLIKA++;
                }
                else {
                    if(BROJ_UKLJUCENIH_SLIKA > 1) {
                        UkljuceneSlike.set(position, false);
                        BROJ_UKLJUCENIH_SLIKA--;
                    }
                    else {
                        holder.checkBox.setChecked(true);
                        Toast.makeText(context, "Bar jedna slika mora biti uključena!", Toast.LENGTH_SHORT).show();
                    }
                }
                //Toast.makeText(context, String.format("BR_UKLJ: %d", BROJ_UKLJUCENIH_SLIKA), Toast.LENGTH_SHORT).show();
                //Toast.makeText(context, PrikazListeSlika(), Toast.LENGTH_LONG).show();
            }
        });

        holder.checkBox.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        holder.slikaImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Toast.makeText(context, String.format("Slika #%d kliknuta", position), Toast.LENGTH_LONG).show();
                ((PodesavanjaForma)context).ProveraPredCuvanje(position + 1);
            }
        });
    }

    @Override
    public int getItemCount() {
        return SlikeId.size();
    }

    private String PrikazListeSlika() {
        String s = "";

        for(int i = 0; i < UkljuceneSlike.size(); i++) {
            if(UkljuceneSlike.get(i)) {
                s += String.format("%d, ", i + 1);
            }
        }

        return s;
    }

    public class Kartica extends RecyclerView.ViewHolder{
        private TextView  nazivTextView,
                          opisTextView;
        private CheckBox  checkBox;
        private ImageView slikaImageView;

        public Kartica(@NonNull View itemView) {
            super(itemView);
            nazivTextView  = itemView.findViewById(R.id.karticaNaziv);
            opisTextView   = itemView.findViewById(R.id.karticaOpis);
            checkBox       = itemView.findViewById(R.id.karticaCheckBox);
            slikaImageView = itemView.findViewById(R.id.karticaSlika);
        }
    }
}
