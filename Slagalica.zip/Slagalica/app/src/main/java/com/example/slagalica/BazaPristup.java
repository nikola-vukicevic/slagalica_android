package com.example.slagalica;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class BazaPristup extends SQLiteOpenHelper {
    public static final String TABELA_MAZIV  = "polja";

    public BazaPristup(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    public List<Integer> CitanjeCeleBaze(){
        List<Integer> polja = new ArrayList<>();

        String         upit      = "SELECT * FROM " + TABELA_MAZIV;
        SQLiteDatabase baza      = this.getReadableDatabase();
        Cursor         pokazivac = baza.rawQuery(upit, null);

        if(pokazivac.moveToFirst()){
            int polje_r     = pokazivac.getInt(0);  polja.add(polje_r);
            int polje_img   = pokazivac.getInt(1);  polja.add(polje_img);
            int polje_s     = pokazivac.getInt(2);  polja.add(polje_s);

            int polje_irnd  = pokazivac.getInt(3);  polja.add(polje_irnd);
            int polje_gr    = pokazivac.getInt(4);  polja.add(polje_gr);
            int polje_klMax = pokazivac.getInt(5);  polja.add(polje_klMax);

            int polje_00    = pokazivac.getInt(6);  polja.add(polje_00);
            int polje_01    = pokazivac.getInt(7);  polja.add(polje_01);
            int polje_02    = pokazivac.getInt(8);  polja.add(polje_02);
            int polje_03    = pokazivac.getInt(9);  polja.add(polje_03);
            int polje_04    = pokazivac.getInt(10); polja.add(polje_04);
            int polje_05    = pokazivac.getInt(11); polja.add(polje_05);
            int polje_06    = pokazivac.getInt(12); polja.add(polje_06);
            int polje_07    = pokazivac.getInt(13); polja.add(polje_07);
            int polje_08    = pokazivac.getInt(14); polja.add(polje_08);
            int polje_09    = pokazivac.getInt(15); polja.add(polje_09);
            int polje_10    = pokazivac.getInt(16); polja.add(polje_10);
            int polje_11    = pokazivac.getInt(17); polja.add(polje_11);
            int polje_12    = pokazivac.getInt(18); polja.add(polje_12);
            int polje_13    = pokazivac.getInt(19); polja.add(polje_13);
            int polje_14    = pokazivac.getInt(20); polja.add(polje_14);
            int polje_15    = pokazivac.getInt(21); polja.add(polje_15);
            int polje_16    = pokazivac.getInt(22); polja.add(polje_16);

            int uklj_01     = pokazivac.getInt(23); polja.add(uklj_01);
            int uklj_02     = pokazivac.getInt(24); polja.add(uklj_02);
            int uklj_03     = pokazivac.getInt(25); polja.add(uklj_03);
            int uklj_04     = pokazivac.getInt(26); polja.add(uklj_04);
            int uklj_05     = pokazivac.getInt(27); polja.add(uklj_05);
            int uklj_06     = pokazivac.getInt(28); polja.add(uklj_06);
            int uklj_07     = pokazivac.getInt(29); polja.add(uklj_07);
            int uklj_08     = pokazivac.getInt(30); polja.add(uklj_08);
            int uklj_09     = pokazivac.getInt(31); polja.add(uklj_09);
            int uklj_10     = pokazivac.getInt(32); polja.add(uklj_10);
        }

        pokazivac.close();
        baza.close();
        return polja;
    }

    public boolean GenerisanjeTabele(){
        SQLiteDatabase baza = this.getWritableDatabase();
        ContentValues  slog = new ContentValues();

        slog.put("red",            1);
        slog.put("polje_slika",    2);
        slog.put("polje_slobodno", 0);

        slog.put("slika_rnd",      1);
        slog.put("gr_pov",         100);
        slog.put("klik_max",       200);

        slog.put("polje_00",       0);
        slog.put("polje_01",       1);
        slog.put("polje_02",       2);
        slog.put("polje_03",       3);
        slog.put("polje_04",       4);
        slog.put("polje_05",       5);
        slog.put("polje_06",       6);
        slog.put("polje_07",       7);
        slog.put("polje_08",       8);
        slog.put("polje_09",       9);
        slog.put("polje_10",       10);
        slog.put("polje_11",       11);
        slog.put("polje_12",       12);
        slog.put("polje_13",       13);
        slog.put("polje_14",       14);
        slog.put("polje_15",       15);
        slog.put("polje_16",       16);

        slog.put("uklj_01",        1);
        slog.put("uklj_02",        1);
        slog.put("uklj_03",        1);
        slog.put("uklj_04",        1);
        slog.put("uklj_05",        1);
        slog.put("uklj_06",        1);
        slog.put("uklj_07",        1);
        slog.put("uklj_08",        1);
        slog.put("uklj_09",        1);
        slog.put("uklj_10",        1);

        long rez = baza.insert(TABELA_MAZIV,null, slog);
        baza.close();
        return rez != -1;
    }

    public Boolean UpisUBazu(List<Integer> polja){
        SQLiteDatabase baza = this.getWritableDatabase();
        ContentValues  slog = new ContentValues();

        slog.put("polje_slika",    polja.get(1));
        slog.put("polje_slobodno", polja.get(2));

        slog.put("slika_rnd",      polja.get(3));
        slog.put("gr_pov",         polja.get(4));
        slog.put("klik_max",       polja.get(5));

        slog.put("polje_00",       polja.get(6));
        slog.put("polje_01",       polja.get(7));
        slog.put("polje_02",       polja.get(8));
        slog.put("polje_03",       polja.get(9));
        slog.put("polje_04",       polja.get(10));
        slog.put("polje_05",       polja.get(11));
        slog.put("polje_06",       polja.get(12));
        slog.put("polje_07",       polja.get(13));
        slog.put("polje_08",       polja.get(14));
        slog.put("polje_09",       polja.get(15));
        slog.put("polje_10",       polja.get(16));
        slog.put("polje_11",       polja.get(17));
        slog.put("polje_12",       polja.get(18));
        slog.put("polje_13",       polja.get(19));
        slog.put("polje_14",       polja.get(20));
        slog.put("polje_15",       polja.get(21));
        slog.put("polje_16",       polja.get(22));

        slog.put("uklj_01",        polja.get(23));
        slog.put("uklj_02",        polja.get(24));
        slog.put("uklj_03",        polja.get(25));
        slog.put("uklj_04",        polja.get(26));
        slog.put("uklj_05",        polja.get(27));
        slog.put("uklj_06",        polja.get(28));
        slog.put("uklj_07",        polja.get(29));
        slog.put("uklj_08",        polja.get(30));
        slog.put("uklj_09",        polja.get(31));
        slog.put("uklj_10",        polja.get(32));

        long rez = baza.update(TABELA_MAZIV, slog, "red=1", null);
        baza.close();
        return rez != -1;
    }

    public Boolean PostojiZapamcenaPozicija(Context context, String ime){
        File dbFile = context.getDatabasePath(ime);
        return dbFile.exists();
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String upit = "CREATE TABLE " + TABELA_MAZIV + " (red INTEGER PRIMARY KEY, polje_slika INTEGER, polje_slobodno INTEGER, slika_rnd INTEGER, gr_pov INTEGER, klik_max INTEGER, polje_00 INTEGER, polje_01 INTEGER, polje_02 INTEGER, polje_03 INTEGER, polje_04 INTEGER, polje_05 INTEGER, polje_06 INTEGER, polje_07 INTEGER, polje_08 INTEGER, polje_09 INTEGER, polje_10 INTEGER, polje_11 INTEGER, polje_12 INTEGER, polje_13 INTEGER, polje_14 INTEGER, polje_15 INTEGER, polje_16 INTEGER, uklj_01 INTEGER, uklj_02 INTEGER, uklj_03 INTEGER, uklj_04 INTEGER, uklj_05 INTEGER, uklj_06 INTEGER, uklj_07 INTEGER, uklj_08 INTEGER, uklj_09 INTEGER, uklj_10 INTEGER); ";
        db.execSQL(upit);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
