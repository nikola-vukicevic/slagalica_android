package com.example.slagalica;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Random;

public class MainActivity extends AppCompatActivity {
    public static final String BAZA_IME    = "polja.db";

    private int[]         Polja,
                          SlikeId;
    private List<Integer> ListaSlika,
                          ZapamcenaPozicija;
    private List<Boolean> UkljuceneSlike;
    private int           BrojRedova,
                          BrojKolona,
                          BrojPolja,
                          SLOBODNO_POLJE,
                          INDEKS_SLIKE,
                          BROJ_SLIKA,
                          BROJ_UKLJUCENIH_SLIKA,
                          PRETHODNI_INDEKS,
                          MAX_KLIK,
                          GR_POV,
                          GR_POV_1,
                          GR_POV_2,
                          // KONTROLNE
                          BROJ_KLIKOVA;
    private Boolean       IgraUToku,
                          NasumicnoBiranjeSlike;
    private Random        GSB;
    private Double        RADIAN;
    private TextView      ISPIS;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // NASE FUNKCIJE

        Inicijalizacija();
    }

    private void Inicijalizacija() {
        BrojRedova            = 4;
        BrojKolona            = 4;
        BrojPolja             = 16;

        Polja                 = new int[BrojPolja + 1];
        for(int i = 0; i <= BrojPolja; i++) Polja[i] = i;

        SLOBODNO_POLJE        = 0;
        INDEKS_SLIKE          = 2;
        BROJ_SLIKA            = 10;
        PRETHODNI_INDEKS      = 2;
        MAX_KLIK              = 200;
        GR_POV                = 100;
        GR_POV_1              = 60;
        GR_POV_2              = 60;
        Log.d("Inicijalizacija", String.format("GR_POV: %d", GR_POV));
        BROJ_KLIKOVA          = 0;
        RADIAN                = 57.295779513082320;
        IgraUToku             = true;
        NasumicnoBiranjeSlike = true;
        GSB                   = new Random();
        ISPIS                 = (TextView)findViewById(R.id.txt_01);
        UkljuceneSlike        = new ArrayList<>();
        ListaSlika            = new ArrayList<>();

        PopunjavanjeNizaSlikeId();
        InicijalizacijaKlikovaZaDugmice();

        // Provera stanja u bazi:

        BazaPristup BP1   = new BazaPristup(getApplicationContext(), "polja.db", null, 1);
        if(BP1.PostojiZapamcenaPozicija(getApplicationContext(), BAZA_IME)) {
            ZapamcenaPozicija = BP1.CitanjeCeleBaze();
            CitanjeZapamcenePozicije();
            Pokretanje(-1);
            Toast.makeText(getApplicationContext(), "Sačuvana pozicija učitana.", Toast.LENGTH_SHORT).show();
        }
        else{
            BP1.GenerisanjeTabele();

            UkljuceneSlike.add(true); // 1
            UkljuceneSlike.add(true); // 2
            UkljuceneSlike.add(true); // 3
            UkljuceneSlike.add(true); // 4
            UkljuceneSlike.add(true); // 5
            UkljuceneSlike.add(true); // 6
            UkljuceneSlike.add(true); // 7
            UkljuceneSlike.add(true); // 8
            UkljuceneSlike.add(true); // 9
            UkljuceneSlike.add(true); // 10

            Pokretanje(1);

            //Toast.makeText(getApplicationContext(), "BAZA KREIRANA", Toast.LENGTH_LONG).show();
        }

        // Provera intenta:

        Intent intent = getIntent();
        if(intent != null) {
            Bundle extras = intent.getExtras();

            if(extras != null) {
                NasumicnoBiranjeSlike = extras.getBoolean("NASUMICNA_SLIKA_2", true);
                INDEKS_SLIKE          = extras.getInt("INDEKS_SLIKE_2", 1);
                MAX_KLIK              = extras.getInt("KLIK_MAX_2", 200);
                GR_POV                = extras.getInt("GR_POV_2", 200);
                GR_POV_1              = GR_POV;
                GR_POV_2              = (int) (GR_POV * 0.6);
                Log.d("Intent", String.format("GR_POV: %d", GR_POV));

                String s = extras.getString("UKLJUCENE_SLIKE_2");

                UkljuceneSlike.clear();
                for(int i = 0; i < s.length(); i++) {
                    UkljuceneSlike.add(s.charAt(i) == '1');
                }

                InicijalizacijaListeSlika();

                //if(!NasumicnoBiranjeSlike) {
                    Pokretanje(-1);
                //}

                Toast.makeText(getApplicationContext(), "Podešavanja sačuvana.", Toast.LENGTH_SHORT).show();
            }
        }

        InicijalizacijaListeSlika();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.app_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch(item.getItemId()){
            case R.id.meni_podesavanja: PokretanjePodesavanja(); return true;
            default: return super.onOptionsItemSelected(item);
        }
    }

    private void PokretanjePodesavanja(){
        Intent intent = new Intent(getApplicationContext(), PodesavanjaForma.class);

        String ukljuceneSlikeStr = "";
        for(int i = 0; i < UkljuceneSlike.size(); i++) {
            ukljuceneSlikeStr += (UkljuceneSlike.get(i) == true)? "1" : "0";
        }

        intent.putExtra("GR_POV_1", GR_POV);
        Log.d("Put extra >>", String.format("GR_POV: %d", GR_POV));
        intent.putExtra("KLIK_MAX_1", MAX_KLIK);
        intent.putExtra("NASUMICNA_SLIKA_1", NasumicnoBiranjeSlike);
        intent.putExtra("INDEKS_SLIKE_1", INDEKS_SLIKE);
        intent.putExtra("BR_UKLJUCENIH_SLIKA_1", ListaSlika.size());
        intent.putExtra("UKLJUCENE_SLIKE_1", ukljuceneSlikeStr);

        startActivity(intent);
        //finish();
    }

    private void InicijalizacijaListeSlika() {
        ListaSlika.clear();
        for (int i = 0; i < UkljuceneSlike.size(); i++) {
            if(UkljuceneSlike.get(i)) {
                ListaSlika.add(i);
            }
        }
    }

    public void dugmeSlika(View view) {
        if(NasumicnoBiranjeSlike) {
            Pokretanje(0);
            //IgraUToku = false;
        }
        else {
            PokretanjePodesavanja();
            //finish();
        }
    }

    public void dugmeMesanje(View view) {
        Pokretanje(1);
        IgraUToku = true;
    }

    public void dugmeSklapanje(View view) {
        Pokretanje(2);
        IgraUToku = false;
    }

    private void Pokretanje(int rezim) {
        // Zadavanje nasumicne slike (REZIM 0 - DugmeSlika)
        if(rezim == 0) {
            if(ListaSlika.size() > 1) {
                while((INDEKS_SLIKE = 1 + ListaSlika.get(GSB.nextInt(ListaSlika.size()))) == PRETHODNI_INDEKS);
                PRETHODNI_INDEKS = INDEKS_SLIKE;
            }
            else {
                PRETHODNI_INDEKS = INDEKS_SLIKE = 1 + ListaSlika.get(0);
            }
        }

        // Zadavanje nasumicne pozicije (REZIM 1 * DugmeNasumicno)
        if(rezim == 1 || rezim == 2) {
            SLOBODNO_POLJE = 0;
            for(int i = 0; i <= BrojPolja; i++) {
                Polja[i] = i;
            }

            if(rezim == 1) ZadavanjePocetnePozicije();
        }

        // Iscrtavanje plocica

        for(int i = 0; i <= BrojPolja; i++) {
            ImageView slika  = (ImageView) findViewById(SlikeId[i]);
            String ime_fajla = "slika_" + String.format("%02d_%02d", INDEKS_SLIKE, Polja[i]);
            int slika_id     = getResources().getIdentifier(ime_fajla, "drawable", getPackageName());
            slika.setImageResource(slika_id);
        }
        BROJ_KLIKOVA++;
        // KONTROLA
        //ISPIS.setText(String.format("K: %d - I: %d - P: %d", BROJ_KLIKOVA, INDEKS_SLIKE, PRETHODNI_INDEKS));
        //Toast.makeText(this, String.format("Slika %d iscrtana", INDEKS_SLIKE), Toast.LENGTH_SHORT).show();
    }

    private void IspisiTekst() {
        /*
        if(!STEK.empty()) {
            ispis.setText(String.format(STEK.toString()));
        }
        else{
            ispis.setText(String.format("Sl: %d", SLOBODNO_POLJE));
        }
        //*/
    }

    private int RacunanjeKorekcije(int r1, int k1, int r2, int k2) {
        if(r1 == r2) {
            if(k1 < k2) {
                return 1;
            }
            else{
                return -1;
            }
        }
        else {
            if(r1 < r2) {
                return 4;
            }
            else{
                return -4;
            }
        }
    }

    private void ProveraResenosti() {
        if(!IgraUToku) return;

        int i;
        Boolean reseno = false;

        for(i = 0; i <= BrojPolja; i++) {
            if(Polja[i] != i) {
                break;
            }
        }

        if(i == BrojPolja + 1) {
            IgraUToku = false;
            Toast.makeText(getApplicationContext(), "REŠENO", Toast.LENGTH_LONG).show();
        }
    }

    private int DugmeKlik(int indeks) {
        if(indeks == SLOBODNO_POLJE) return SLOBODNO_POLJE;

        if(indeks == 1 && SLOBODNO_POLJE == 0) {
            ZamenaSlika(0, 1);
            SLOBODNO_POLJE = 1;
            ProveraResenosti();
            return 0;
        }

        if(indeks == 0 && SLOBODNO_POLJE == 1) {
            ZamenaSlika(1, 0);
            SLOBODNO_POLJE = 0;
            ProveraResenosti();
            return 1;
        }

        int r_tr, k_tr, r_sl, k_sl, korekcija;

        if(indeks == 0) {
            r_tr = -1;
            k_tr = 0;
        }
        else{
            r_tr = (indeks - 1) / BrojKolona;
            k_tr = (indeks - 1) % BrojKolona;
        }

        if(SLOBODNO_POLJE == 0) {
            r_sl = -1;
            k_sl = 0;
        }
        else{
            r_sl = (SLOBODNO_POLJE - 1) / BrojKolona;
            k_sl = (SLOBODNO_POLJE - 1) % BrojKolona;
        }

        if(r_tr != r_sl && k_tr != k_sl) return SLOBODNO_POLJE;

        if(SLOBODNO_POLJE == 0/* && k_tr == 0*/) {
            PrvaKolonaNaGore(indeks);
            ProveraResenosti();
            return indeks - 4;
        }

        if(indeks == 0) {
            PrvaKolonaNaDole(indeks);
            ProveraResenosti();
            return 1;
        }

        korekcija = RacunanjeKorekcije(r_sl, k_sl, r_tr, k_tr);

        for(int i = SLOBODNO_POLJE; i != indeks; i += korekcija) {
            ZamenaSlika(i, i + korekcija);
            SLOBODNO_POLJE += korekcija;
        }

        //Toast.makeText(getApplicationContext(), "STANDARDNI POMERAJ", Toast.LENGTH_LONG).show();
        //return SLOBODNO_POLJE;
        ProveraResenosti();
        return indeks - korekcija;
    }

    private int PrvaKolonaNaGore(int polje_kraj) {
        ZamenaSlika(0, 1);
        SLOBODNO_POLJE = 1;

        while(SLOBODNO_POLJE < polje_kraj) {
            ZamenaSlika(SLOBODNO_POLJE, SLOBODNO_POLJE + 4);
            SLOBODNO_POLJE += 4;
        }

        //Toast.makeText(getApplicationContext(), "PRVA KOLONA NA GORE", Toast.LENGTH_LONG).show();
        return  SLOBODNO_POLJE;
    }

    private int PrvaKolonaNaDole(int polje_kraj) {
        while(SLOBODNO_POLJE >= 5) {
            ZamenaSlika(SLOBODNO_POLJE, SLOBODNO_POLJE - 4);
            SLOBODNO_POLJE -= 4;
        }

        ZamenaSlika(0, 1);
        SLOBODNO_POLJE = 0;

        //Toast.makeText(getApplicationContext(), "PRVA KOLONA NA DOLE", Toast.LENGTH_LONG).show();

        return SLOBODNO_POLJE;
    }

    private void ZamenaSlika(int i1, int i2) {
        String ime_1 = "slika_" + String.format("%02d_%02d", INDEKS_SLIKE, Polja[i1]);
        String ime_2 = "slika_" + String.format("%02d_%02d", INDEKS_SLIKE, Polja[i2]);

        int p     = Polja[i1];
        Polja[i1] = Polja[i2];
        Polja[i2] = p;

        int slika_id_1 = getResources().getIdentifier(ime_1, "drawable", getPackageName());
        int slika_id_2 = getResources().getIdentifier(ime_2, "drawable", getPackageName());

        ImageView slika_1 = (ImageView) findViewById(SlikeId[i1]);
        ImageView slika_2 = (ImageView) findViewById(SlikeId[i2]);

        slika_1.setImageResource(slika_id_2);
        slika_2.setImageResource(slika_id_1);
    }

    private List<Integer> GenerisanjeListeZapamcenaPozicija() {
        List<Integer> lista = new ArrayList<>();

        lista.add(1);                                      // 0    - red
        lista.add(INDEKS_SLIKE);                           // 1    - Indeks slike
        lista.add(SLOBODNO_POLJE);                         // 2    - Slobodno polje
        lista.add((NasumicnoBiranjeSlike == true)? 1 : 0); // 3    - Nasumicna slika?
        lista.add(GR_POV);                                 // 4    - Granica za prevlacenje
        lista.add(MAX_KLIK);                               // 5    - Duzina klika
                                                           // 6-22 - Polja
        lista.add(Polja[0]);
        lista.add(Polja[1]);  lista.add(Polja[2]);  lista.add(Polja[3]);  lista.add(Polja[4]);
        lista.add(Polja[5]);  lista.add(Polja[6]);  lista.add(Polja[7]);  lista.add(Polja[8]);
        lista.add(Polja[9]);  lista.add(Polja[10]); lista.add(Polja[11]); lista.add(Polja[12]);
        lista.add(Polja[13]); lista.add(Polja[14]); lista.add(Polja[15]); lista.add(Polja[16]);

        lista.add((UkljuceneSlike.get(0) == true)? 1 : 0);  // 23 - SLika 1 ukljucena
        lista.add((UkljuceneSlike.get(1) == true)? 1 : 0);  // 24 - SLika 2 ukljucena
        lista.add((UkljuceneSlike.get(2) == true)? 1 : 0);  // 25 - SLika 3 ukljucena
        lista.add((UkljuceneSlike.get(3) == true)? 1 : 0);  // 26 - SLika 4 ukljucena
        lista.add((UkljuceneSlike.get(4) == true)? 1 : 0);  // 27 - SLika 5 ukljucena
        lista.add((UkljuceneSlike.get(5) == true)? 1 : 0);  // 28 - SLika 6 ukljucena
        lista.add((UkljuceneSlike.get(6) == true)? 1 : 0);  // 29 - SLika 7 ukljucena
        lista.add((UkljuceneSlike.get(7) == true)? 1 : 0);  // 30 - SLika 8 ukljucena
        lista.add((UkljuceneSlike.get(8) == true)? 1 : 0);  // 31 - SLika 9 ukljucena
        lista.add((UkljuceneSlike.get(9) == true)? 1 : 0);  // 32 - SLika 10 ukljucena

        return lista;
    }

    private void CitanjeZapamcenePozicije() {
        INDEKS_SLIKE          = ZapamcenaPozicija.get(1);
        PRETHODNI_INDEKS      = ZapamcenaPozicija.get(1);
        SLOBODNO_POLJE        = ZapamcenaPozicija.get(2);
        NasumicnoBiranjeSlike = ZapamcenaPozicija.get(3) == 1;
        GR_POV                = ZapamcenaPozicija.get(4);
        GR_POV_1              = GR_POV;
        GR_POV_2              = (int)(GR_POV * 0.6);
        Log.d("Citanje zap. poz.", String.format("GR_POV: %d", GR_POV));
        MAX_KLIK              = ZapamcenaPozicija.get(5);

        Polja[0]  = ZapamcenaPozicija.get(6);

        Polja[1]  = ZapamcenaPozicija.get(7);
        Polja[2]  = ZapamcenaPozicija.get(8);
        Polja[3]  = ZapamcenaPozicija.get(9);
        Polja[4]  = ZapamcenaPozicija.get(10);

        Polja[5]  = ZapamcenaPozicija.get(11);
        Polja[6]  = ZapamcenaPozicija.get(12);
        Polja[7]  = ZapamcenaPozicija.get(13);
        Polja[8]  = ZapamcenaPozicija.get(14);

        Polja[9]  = ZapamcenaPozicija.get(15);
        Polja[10] = ZapamcenaPozicija.get(16);
        Polja[11] = ZapamcenaPozicija.get(17);
        Polja[12] = ZapamcenaPozicija.get(18);

        Polja[13] = ZapamcenaPozicija.get(19);
        Polja[14] = ZapamcenaPozicija.get(20);
        Polja[15] = ZapamcenaPozicija.get(21);
        Polja[16] = ZapamcenaPozicija.get(22);

        UkljuceneSlike.clear();

        UkljuceneSlike.add(ZapamcenaPozicija.get(23) == 1);
        UkljuceneSlike.add(ZapamcenaPozicija.get(24) == 1);
        UkljuceneSlike.add(ZapamcenaPozicija.get(25) == 1);
        UkljuceneSlike.add(ZapamcenaPozicija.get(26) == 1);
        UkljuceneSlike.add(ZapamcenaPozicija.get(27) == 1);
        UkljuceneSlike.add(ZapamcenaPozicija.get(28) == 1);
        UkljuceneSlike.add(ZapamcenaPozicija.get(29) == 1);
        UkljuceneSlike.add(ZapamcenaPozicija.get(30) == 1);
        UkljuceneSlike.add(ZapamcenaPozicija.get(31) == 1);
        UkljuceneSlike.add(ZapamcenaPozicija.get(32) == 1);

        InicijalizacijaListeSlika();
    }

    @Override
    protected void onStop() {
        super.onStop();
        PisanjeUBazu();
    }

    private void PisanjeUBazu() {
        ZapamcenaPozicija = GenerisanjeListeZapamcenaPozicija();
        BazaPristup BP1   = new BazaPristup(getApplicationContext(), "polja.db", null, 1);
        BP1.UpisUBazu(ZapamcenaPozicija);
    }

    private void ZadavanjePocetnePozicije() {
        ShuffleNiza(Polja, 2, 16, BrojPolja - 1);
        if(ParnostMatrice(Polja, 2) %2 == 1) {
            int p    = Polja[2];
            Polja[2] = Polja[3];
            Polja[3] = p;
        }
    }

    private int ParnostPolja(int a[], int polje) {
        int s = 0;
        for(int i = polje + 1; i < a.length; i++) {
            if(a[i] < a[polje]) {
                s++;
            }
        }
        return s;
    }

    private int ParnostMatrice(int a[], int pocetno) {
        int s = 0;
        for(int i = pocetno; i < a.length; i++) {
            s += ParnostPolja(a, i);
        }
        return s;
    }

    private void ShuffleNiza(int[] a, int levi, int desni, int GRANICA) {
        for(int i = levi; i <= desni; i++) {
            int i_rnd = GSB.nextInt(GRANICA) + 2;
            int p     = a[i];
            a[i]      = a[i_rnd];
            a[i_rnd]  =p;
        }
    }

    private int smerKretanjaUgao(float x1, float y1, float x2, float y2) {
        double ugao = Math.atan2(y1 - y2, x2 - x1) * RADIAN;

        if(ugao >= 45  && ugao <= 135) return 1;
        if(ugao >= 135 && ugao <= 225) return 4;
        if(ugao >= 225 && ugao <= 315) return 3;
        return 2;
    }

    private int smerKretanjaPokret(float x1, float y1, float x2, float y2) {
        float dx = x2 - x1;
        float dy = y2 - y1;

        if(dx == dy) {
            return 0;
        }

        if(Math.abs(dx) > Math.abs(dy)) {
            if(dx > 0) {
                return 2;
            }
            else{
                return 4;
            }
        }
        else{
            if(dy > 0) {
                return 3;
            }
            else{
                return  1;
            }
        }
    }

    private int smerKretanjaOcekivani(int i, int s) {
        int r_i, k_i, r_s, k_s;

        if(i == 0) {
            r_i = -1;
            k_i = 0;
        }
        else{
            r_i = (i - 1) / BrojKolona;
            k_i = (i - 1) % BrojKolona;
        }

        if(s == 0) {
            r_s = -1;
            k_s = 0;
        }
        else{
            r_s = (s - 1) / BrojKolona;
            k_s = (s - 1) % BrojKolona;
        }

        if(r_i != r_s && k_i != k_s) return 0;

        if(r_i == r_s) {
            if(k_i < k_s) {
                return 2;
            }
            else{
                return 4;
            }
        }
        else{
            if(r_i < r_s) {
                return 3;
            }
            else{
                return 1;
            }
        }
    }

    private int NadjiIndeksSlike(int ajDi) {
        int ind = -1;
        switch(ajDi) {
            case R.id.slike_id_00: ind = 0;  break;

            case R.id.slike_id_11: ind = 1;  break;
            case R.id.slike_id_12: ind = 2;  break;
            case R.id.slike_id_13: ind = 3;  break;
            case R.id.slike_id_14: ind = 4;  break;

            case R.id.slike_id_21: ind = 5;  break;
            case R.id.slike_id_22: ind = 6;  break;
            case R.id.slike_id_23: ind = 7;  break;
            case R.id.slike_id_24: ind = 8;  break;

            case R.id.slike_id_31: ind = 9;  break;
            case R.id.slike_id_32: ind = 10; break;
            case R.id.slike_id_33: ind = 11; break;
            case R.id.slike_id_34: ind = 12; break;

            case R.id.slike_id_41: ind = 13; break;
            case R.id.slike_id_42: ind = 14; break;
            case R.id.slike_id_43: ind = 15; break;
            case R.id.slike_id_44: ind = 16; break;

            default: break;
        }

        return ind;
    }

    @SuppressLint("ClickableViewAccessibility")
    private void InicijalizacijaKlikovaZaDugmice() {
        for(int i = 0; i <= BrojPolja; i++) {
            ImageView slika = (ImageView) findViewById(SlikeId[i]);

            slika.setOnTouchListener(new View.OnTouchListener() {
                private Float            X, Y;
                private long             klikPocetak;
                private int              ind          = 0,
                                         brPovlacenja = 0;
                private Boolean          kliknuto     = false,
                                         mozeOtpust   = true;

                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    if(!kliknuto) {
                        ind = NadjiIndeksSlike(v.getId());
                    }

                    // PRVI KLIK:

                    if (event.getAction() == MotionEvent.ACTION_DOWN) {
                        klikPocetak = Calendar.getInstance().getTimeInMillis();
                        X = event.getX();
                        Y = event.getY();
                        Log.d("ACTION_DOWN", String.format("X: %.4f Y: %.4f", X, Y));
                        return true;
                    }

                    // POVLACENJE:

                    kliknuto      = true;
                    float X2      = event.getX(),
                          Y2      = event.getY(),
                          delta_X = Math.abs(X2 - X),
                          delta_Y = Math.abs(Y2 - Y),
                          delta   = (delta_X >= delta_Y)? delta_X : delta_Y;
                    int smerKretanja  = smerKretanjaPokret(X, Y, X2, Y2);
                    int ocekivaniSmer = smerKretanjaOcekivani(ind, SLOBODNO_POLJE);

                    if(ind == 1 && SLOBODNO_POLJE == 0) {
                        ocekivaniSmer = 1;
                    }

                    if(ind == 0 && (SLOBODNO_POLJE == 1 || SLOBODNO_POLJE == 5 || SLOBODNO_POLJE == 9 || SLOBODNO_POLJE == 13)) {
                        ocekivaniSmer = 3;
                    }

                    Log.d("ACTION_MOVE", String.format("X: %.4f Y: %.4f X2: %.4f Y2: %.4f De: %.4f", X, Y, X2, Y2, delta));

                    //ISPIS.setText(String.format("I: %d S: %d D: %.2f", ind, SLOBODNO_POLJE, delta));

                    // POMERANJE PRI PREVLACENJU - BEZ PODIZANJA PRSTA, AKO JE PRST PRESAO NA
                    // PROSTOR SUSEDNE PLOCICE

                    if(delta > GR_POV && smerKretanja == ocekivaniSmer && kliknuto) {
                        ind        = DugmeKlik(ind);
                        GR_POV     = GR_POV_2;
                        Log.d("Povlacenje - GR_POV_2", String.format("GR_POV: %d", GR_POV));
                        X          = event.getX();
                        Y          = event.getY();
                        mozeOtpust = false;
                        return true;
                    }

                    // POMERANJE NA KLIK ILI PRI PREVLACENJU - SA PODIZANJEM PRSTA (AKO JE PRST
                    // PRESAO ODREDJENO RASTOJANJE (SPRECAVAMO SLUCAJNE KLIKOVE))

                    if(event.getAction() == MotionEvent.ACTION_UP) {
                        long klikTrajanje = Calendar.getInstance().getTimeInMillis() - klikPocetak;

                        if(mozeOtpust && (smerKretanja == 0 || smerKretanja == ocekivaniSmer) && (klikTrajanje < MAX_KLIK || delta > GR_POV)) {
                            //ISPIS.setText("DVOSTRUKI IF");
                            DugmeKlik(ind);
                            X            = event.getX();
                            Y            = event.getY();
                            //klikTrajanje = MAX_KLIK + 100;
                        }
                        //*/
                        ind        = 0;
                        GR_POV     = GR_POV_1;
                        Log.d("Povlacenje - GR_POV_1", String.format("GR_POV: %d", GR_POV));
                        kliknuto   = false;
                        mozeOtpust = true;
                        Log.d("ACTION_UP", String.format("X: %.4f Y: %.4f X2: %.4f Y2: %.4f De: %.4f", X, Y, X2, Y2, delta));
                        return false;
                    }

                    return true;
                }
            });
        }
    }

    private void PopunjavanjeNizaSlikeId() {
        SlikeId = new int[BrojPolja + 1];

        SlikeId[0]  = R.id.slike_id_00;

        SlikeId[1]  = R.id.slike_id_11;
        SlikeId[2]  = R.id.slike_id_12;
        SlikeId[3]  = R.id.slike_id_13;
        SlikeId[4]  = R.id.slike_id_14;

        SlikeId[5]  = R.id.slike_id_21;
        SlikeId[6]  = R.id.slike_id_22;
        SlikeId[7]  = R.id.slike_id_23;
        SlikeId[8]  = R.id.slike_id_24;

        SlikeId[9]  = R.id.slike_id_31;
        SlikeId[10] = R.id.slike_id_32;
        SlikeId[11] = R.id.slike_id_33;
        SlikeId[12] = R.id.slike_id_34;

        SlikeId[13] = R.id.slike_id_41;
        SlikeId[14] = R.id.slike_id_42;
        SlikeId[15] = R.id.slike_id_43;
        SlikeId[16] = R.id.slike_id_44;
    }
}
